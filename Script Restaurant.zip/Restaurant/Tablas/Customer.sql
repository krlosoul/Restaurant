--CREAR TABLA
CREATE TABLE restaurant.customer(
    IdCustomer  VARCHAR(10) NOT NULL,
    FirstName 	VARCHAR(50) NOT NULL,
    LastName  	VARCHAR(50) NOT NULL,
    Address   	VARCHAR(50),
    PhoneNumber VARCHAR(10)
);
--INDEX
CREATE UNIQUE INDEX restaurant.pk_customer ON restaurant.customer (IdCustomer ASC);
--PRIMARY KEY
ALTER TABLE restaurant.customer ADD CONSTRAINT pk_customer PRIMARY KEY (IdCustomer);