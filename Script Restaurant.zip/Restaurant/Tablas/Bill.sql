--SEQUENCE
CREATE SEQUENCE restaurant."seq_pk_bill" INCREMENT BY 1 MINVALUE 1 MAXVALUE 9999999999999999999999999999 NOCYCLE CACHE 20 ORDER 
--CREAR TABLA
CREATE TABLE restaurant.bill(
    IdBill			NUMBER default restaurant."seq_pk_bill".nextval,
    IdCustomer   	VARCHAR(10) NOT NULL,
	IdDiningTable	NUMBER(10,0) NOT NULL,
    IdWaiter		NUMBER(10,0) NOT NULL,
    CreationDate	DATE NOT NULL
);
--INDEX
CREATE UNIQUE INDEX restaurant.pk_bill ON restaurant.bill (IdBill ASC);
CREATE INDEX restaurant.fk_bill_customer ON restaurant.bill (IdCustomer ASC);
CREATE INDEX restaurant.fk_bill_diningtable ON restaurant.bill (IdDiningTable ASC);
CREATE INDEX restaurant.fk_bill_waiter ON restaurant.bill (IdWaiter ASC);
--PRIMARY KEY
ALTER TABLE restaurant.bill ADD CONSTRAINT pk_bill PRIMARY KEY (IdBill);
--FOREING KEY
ALTER TABLE restaurant.bill ADD CONSTRAINT fk_bill_customer FOREIGN KEY (IdCustomer) REFERENCES restaurant.customer(IdCustomer);
ALTER TABLE restaurant.bill ADD CONSTRAINT fk_bill_diningtable FOREIGN KEY (IdDiningTable) REFERENCES restaurant.diningtable(IdDiningTable);
ALTER TABLE restaurant.bill ADD CONSTRAINT fk_bill_waiter FOREIGN KEY (IdWaiter) REFERENCES restaurant.waiter(IdWaiter);