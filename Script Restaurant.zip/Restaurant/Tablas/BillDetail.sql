CREATE SEQUENCE restaurant."seq_pk_billdetail" INCREMENT BY 1 MINVALUE 1 MAXVALUE 9999999999999999999999999999 NOCYCLE CACHE 20 ORDER 
--CREAR TABLA
CREATE TABLE restaurant.billdetail(
    IdBillDetail	NUMBER default restaurant."seq_pk_billdetail".nextval,
    IdBill			NUMBER NOT NULL,
	IdFood			NUMBER NOT NULL,
    Quantity		NUMBER(3) NOT NULL,
    Price			NUMBER(10,3) NOT NULL
);
--INDEX
CREATE UNIQUE INDEX restaurant.pk_billdetail ON restaurant.billdetail (IdBillDetail ASC);
CREATE INDEX restaurant.fk_billdetail_bill ON restaurant.billdetail (IdBill ASC);
CREATE INDEX restaurant.fk_billdetail_food ON restaurant.billdetail (IdFood ASC);
--PRIMARY KEY
ALTER TABLE restaurant.billdetail ADD CONSTRAINT pk_billdetail PRIMARY KEY (IdBillDetail);
--FOREING KEY
ALTER TABLE restaurant.billdetail ADD CONSTRAINT fk_billdetail_bill FOREIGN KEY (IdBill) REFERENCES restaurant.bill(IdBill);
ALTER TABLE restaurant.billdetail ADD CONSTRAINT fk_billdetail_food FOREIGN KEY (IdFood) REFERENCES restaurant.food(IdFood);
