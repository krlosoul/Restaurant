--SEQUENCE
CREATE SEQUENCE restaurant."seq_pk_waiter" INCREMENT BY 1 MINVALUE 1 MAXVALUE 9999999999999999999999999999 NOCYCLE CACHE 20 ORDER 
--CREAR TABLA
CREATE TABLE restaurant.waiter(
    IdWaiter	   NUMBER default restaurant."seq_pk_waiter".nextval,
    FirstName 	   VARCHAR(50) NOT NULL,
    LastName  	   VARCHAR(50) NOT NULL,
    Age		  	   VARCHAR(2),
    AdmissionDate  DATE
);
--INDEX
CREATE UNIQUE INDEX restaurant.pk_waiter ON restaurant.waiter (IDWaiter ASC);
--PRIMARY KEY
ALTER TABLE restaurant.waiter ADD CONSTRAINT pk_waiter PRIMARY KEY (IDWaiter);