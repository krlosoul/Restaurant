--SEQUENCE
CREATE SEQUENCE restaurant."seq_pk_food" INCREMENT BY 1 MINVALUE 1 MAXVALUE 9999999999999999999999999999 NOCYCLE CACHE 20 ORDER 
--CREAR TABLA
CREATE TABLE restaurant.food(
    IdFood	NUMBER default restaurant."seq_pk_food".nextval,
    Name	VARCHAR(50) NOT NULL,
	Price	NUMBER(10,3) NOT NULL
);
--INDEX
CREATE UNIQUE INDEX restaurant.pk_food ON restaurant.food (IdFood ASC);
--PRIMARY KEY
ALTER TABLE restaurant.food ADD CONSTRAINT pk_food PRIMARY KEY (IdFood);
